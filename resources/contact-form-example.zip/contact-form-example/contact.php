<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Contact Form Example</title>
</head>

<body>
<?php
	function spamcheck($field)
	{
		$field = filter_var($field, FILTER_SANITIZE_EMAIL);
		
		if (filter_var($field, FILTER_VALIDATE_EMAIL)) {
			return TRUE;
		}
		
		else {
			return FALSE;
		}
	}

	if (isset($_POST['email'])) {
		
		$mailcheck = spamcheck($_POST['email']);
		if ($mailcheck == FALSE) {
			$submit_message = "Please input your information again.";
		} else {
			$fullname    = $_POST['fullname'];
			$email   = $_POST['email'];
			$phone   = $_POST['phone'];
			$message = $_POST['message'];
			$headers = "From: James D Mosier Portfolio Site";
			$subject = "From: $fullname";
			
			$msg = "Email: $email\nPhone Number: $phone\nMessage: $message";
			mail("jdm113@zips.uakron.edu", $subject, $msg, $headers);
			
			$submit_message = "Thank you for your message, we will get back to you very soon!";
		}
	}
?>
<form role="form" class="" name="message-me" id="contact-form" action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="POST" enctype="multipart/form-data">
  <div class="form-group">
    <label for="input1" class="form-label">Name</label>
    <input type="text" class="form-control" name="fullname" id="input1" placeholder="Your name">
  </div>
  <div class="form-group">
    <label for="input2" class="form-label">Email Address</label>
    <input type="text" class="form-control" name="email" id="input2" placeholder="Your email address">
  </div>
  <div class="form-group">
    <label for="phone-input" class="form-label">Phone Number</label>
    <input type="text" class="form-control" name="phone" id="phone-input" placeholder="Your phone number (optional)">
  </div>
  <div class="form-group">
    <label for="input3" class="form-label">Message</label>
    <textarea name="message" id="input3" rows="8" class="form-control" placeholder="Type your message here"></textarea>
  </div>
  <div class="form-group">
    <button type="submit" class="submit-button">Send</button>
  </div>
</form>
</body>
</html>